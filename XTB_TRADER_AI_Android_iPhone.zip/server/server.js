require("dotenv").config();
const express = require("express");
const cors = require("cors");
const OpenAI = require("openai");

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const instructions = `
Jesteś XTB Trader AI — życzliwym, bezpośrednim asystentem i kolegą użytkownika.
Rozmawiaj po polsku, naturalnie i bez nadmiernego formalizmu. Pomagaj także w zwykłych,
codziennych sprawach, nie ograniczaj się do giełdy. Pamiętaj kontekst przekazany w historii
bieżącej rozmowy, ale nie twierdź, że pamiętasz inne rozmowy, jeśli nie masz ich w kontekście.
W tematach inwestycyjnych wyjaśniaj ryzyko, odróżniaj fakty od przypuszczeń, nie obiecuj zysków,
nie wymyślaj cen ani notowań. Jeśli nie masz aktualnych danych, poproś o wykres lub dane.
Nie wydawaj kategorycznych poleceń kupna/sprzedaży. Przedstawiaj scenariusze i ryzyko.
Użytkownik sam zatwierdza każdą transakcję. Nigdy nie proś o hasło XTB, kody 2FA ani sekrety.
Nie twierdź, że masz dostęp do rachunku, notowań na żywo lub możliwości składania zleceń,
jeśli nie zostały jawnie skonfigurowane.
Znany plan użytkownika: chce regularnie wpłacać około 100 zł tygodniowo, ma obecnie
około 232,26 zł wolnych środków (wartość do potwierdzenia), a jego aspiracyjny cel to
20 000 zł na samochód. Nie przedstawiaj tego celu jako gwarantowanego ani osiągalnego
samym tradingiem.
`;

app.post("/chat", async (req, res) => {
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const safeMessages = messages
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20);

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions,
      input: safeMessages.map(m => ({
        role: m.role,
        content: [{ type: "input_text", text: m.content }]
      }))
    });

    res.json({ reply: response.output_text || "Nie udało się przygotować odpowiedzi." });
  } catch (err) {
    console.error("Chat API error:", err.message);
    res.status(500).json({ error: "Nie udało się połączyć z asystentem." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`XTB Trader AI server listening on ${port}`));

import React, { useState } from "react";
import {
  SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList,
  KeyboardAvoidingView, Platform, ActivityIndicator, StyleSheet
} from "react-native";
import { StatusBar } from "expo-status-bar";

const API_URL = "http://YOUR_SERVER_ADDRESS:3000/chat"; // ustaw adres wdrożonego backendu

const starter = {
  role: "assistant",
  content: "Cześć! Jestem Twoim XTB Trader AI. Mogę rozmawiać z Tobą normalnie, pomagać w codziennych sprawach i analizować inwestycje. Nie wykonuję transakcji za Ciebie. Co dziś robimy?"
};

export default function App() {
  const [messages, setMessages] = useState([starter]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    const next = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");
    setBusy(true);
    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next.slice(-20) })
      });
      if (!response.ok) throw new Error("Serwer zwrócił błąd.");
      const data = await response.json();
      setMessages([...next, { role: "assistant", content: data.reply || "Nie udało się uzyskać odpowiedzi." }]);
    } catch (e) {
      setMessages([...next, {
        role: "assistant",
        content: "Nie mogę teraz połączyć się z asystentem. Sprawdź połączenie i konfigurację serwera."
      }]);
    } finally {
      setBusy(false);
    }
  }

  function renderMessage({ item }) {
    const mine = item.role === "user";
    return (
      <View style={[styles.bubble, mine ? styles.mine : styles.theirs]}>
        <Text style={styles.message}>{item.content}</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>TWÓJ OSOBISTY ASYSTENT</Text>
            <Text style={styles.title}>XTB TRADER <Text style={styles.gold}>AI</Text></Text>
            <Text style={styles.subtitle}>Kolega • rozmowa • inwestowanie</Text>
          </View>
          <View style={styles.status}><View style={styles.dot}/><Text style={styles.statusText}>ASYSTENT</Text></View>
        </View>

        <View style={styles.notice}>
          <Text style={styles.noticeText}>AI analizuje i podpowiada. Każdą transakcję zatwierdzasz sam.</Text>
        </View>

        <FlatList
          style={styles.list}
          contentContainerStyle={styles.listContent}
          data={messages}
          keyExtractor={(_, i) => String(i)}
          renderItem={renderMessage}
        />
        {busy && <View style={styles.typing}><ActivityIndicator color="#E7B84D"/><Text style={styles.typingText}>Asystent pisze…</Text></View>}
        <View style={styles.composer}>
          <TextInput
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder="Napisz do swojego asystenta…"
            placeholderTextColor="#8D8D93"
            multiline
          />
          <TouchableOpacity style={styles.send} onPress={send} disabled={busy || !input.trim()}>
            <Text style={styles.sendText}>➤</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.footer}>Nie podawaj hasła XTB ani kodów 2FA. AI nie gwarantuje zysków.</Text>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#090A0D" },
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 15, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  eyebrow: { color: "#D6A642", fontSize: 10, letterSpacing: 2, fontWeight: "700" },
  title: { color: "white", fontSize: 25, fontWeight: "900", marginTop: 4 },
  gold: { color: "#E7B84D" },
  subtitle: { color: "#A4A5AA", fontSize: 12, marginTop: 3 },
  status: { borderWidth: 1, borderColor: "#44404A", borderRadius: 20, paddingVertical: 7, paddingHorizontal: 10, flexDirection: "row", alignItems: "center", gap: 6 },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#E7B84D" },
  statusText: { color: "#D8D8DC", fontSize: 9, fontWeight: "700" },
  notice: { marginHorizontal: 16, padding: 10, borderRadius: 10, backgroundColor: "#211D13", borderWidth: 1, borderColor: "#4D3B18" },
  noticeText: { color: "#E9D8AE", fontSize: 11, textAlign: "center" },
  list: { flex: 1 },
  listContent: { padding: 16, gap: 12 },
  bubble: { maxWidth: "88%", padding: 13, borderRadius: 16 },
  mine: { alignSelf: "flex-end", backgroundColor: "#6E531E", borderBottomRightRadius: 4 },
  theirs: { alignSelf: "flex-start", backgroundColor: "#202127", borderBottomLeftRadius: 4 },
  message: { color: "#F6F6F7", fontSize: 15, lineHeight: 21 },
  typing: { flexDirection: "row", gap: 9, alignItems: "center", paddingHorizontal: 20, paddingBottom: 8 },
  typingText: { color: "#B6B6BC", fontSize: 12 },
  composer: { flexDirection: "row", alignItems: "flex-end", padding: 12, gap: 9, borderTopWidth: 1, borderTopColor: "#292A30" },
  input: { flex: 1, maxHeight: 110, minHeight: 45, color: "white", backgroundColor: "#1B1C22", borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11, fontSize: 15 },
  send: { width: 46, height: 46, borderRadius: 14, backgroundColor: "#D6A642", alignItems: "center", justifyContent: "center" },
  sendText: { color: "#17130A", fontSize: 21, fontWeight: "900" },
  footer: { color: "#777982", fontSize: 10, textAlign: "center", paddingHorizontal: 14, paddingBottom: 8 }
});

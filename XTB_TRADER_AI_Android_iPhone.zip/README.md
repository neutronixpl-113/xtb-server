# XTB TRADER AI — aplikacja na Androida i iPhone'a

To jest wieloplatformowy projekt startowy oparty na Expo / React Native. Jedna baza kodu może obsłużyć Androida i iOS.

## Co zawiera
- ekran rozmowy z asystentem po polsku,
- backend pośredniczący w rozmowie z modelem AI,
- instrukcje osobowości: pomocny kolega + ostrożny asystent inwestycyjny,
- bezpieczniejszy układ: klucz API pozostaje na serwerze, nie w aplikacji mobilnej.

## Czego jeszcze NIE ma
- publikacji w Google Play ani App Store,
- połączenia z rachunkiem XTB,
- notowań giełdowych na żywo,
- pamięci między uruchomieniami / kontami użytkowników,
- analizy zdjęć wykresów,
- składania zleceń.

Nie wpisuj danych logowania do XTB do aplikacji. Integracja z brokerem, jeśli będzie w ogóle możliwa, musi korzystać wyłącznie z oficjalnie wspieranych metod i uprawnień.

## Uruchomienie backendu
1. Zainstaluj Node.js LTS na komputerze lub serwerze.
2. Wejdź do folderu `server`.
3. Uruchom `npm install`.
4. Skopiuj `.env.example` do `.env`.
5. Wstaw własny klucz OpenAI API w `.env`. Nie udostępniaj go i nie umieszczaj w aplikacji mobilnej.
6. Uruchom `npm start`.
7. Wdróż backend pod adresem HTTPS. Nie wystawiaj klucza API w aplikacji.

## Uruchomienie aplikacji
1. Zainstaluj Node.js LTS.
2. Wejdź do folderu `app`.
3. Uruchom `npm install`.
4. W `App.js` ustaw `API_URL` na adres HTTPS wdrożonego backendu zakończony `/chat`.
5. Uruchom `npx expo start`.
6. Otwórz projekt w Expo Go na telefonie albo skonfiguruj build przez EAS.

## Ważne przed publikacją
- dodać logowanie i osobne konta użytkowników, jeśli aplikacja ma być prywatna,
- dodać bezpieczne przechowywanie historii i możliwość jej usunięcia,
- dodać limity użycia API i ochronę przed nadużyciami,
- dodać politykę prywatności, regulamin i testy,
- skonfigurować identyfikatory aplikacji, podpisy i konta deweloperskie Apple/Google.

## Zasada działania
Asystent odpowiada jak rozmowny, życzliwy pomocnik, ale nie udaje dostępu do notowań lub rachunku. W inwestowaniu przedstawia scenariusze i ryzyko; użytkownik sam podejmuje decyzje.
